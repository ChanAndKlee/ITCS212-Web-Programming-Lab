/* Model: Connect to the Student JSON */
const studentJSON = require('../resources/data/student.json');
module.exports.studentJSON = studentJSON;
/* -------------------------- */